<?php $__env->startSection("browsertitle"); ?>
    Welcome
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content"); ?>
    <div class="gridmain">
        <div class="ghostdoor-start-explain">
            <div class="ghostdoor-start-explain-title">
                <h1>Storyline</h1>
            </div>
            <div class="ghostdoor-start-explain-story">
                <p>It's Halloween and you're dressed up and you are going along every house in your street with your brother to collect candies but suddenly out of nowhere your brother runs away  towards a deserted castle so you ran after him in to the deserted castle.
                    but once you're in the castle you can't find your brother anymore. It's very dark but there are a few candles and you see 5 doors which door do you choose ...</p>
            </div>
        </div>
        <div class="ghostdoor-start-mainstart">
            <div class="ghostdoor-start-mainstart-title">
                <h1>King Boo's castle</h1>
            </div>
            <div class="ghostdoor-start-mainstart-img">
                <img id="kingboo" src="/img/Kingboo.png">
            </div>
            <div class="ghostdoor-start-mainstart-startbtn">
            <a href="/play">Start</a>
            </div>
        </div>
        <div class="ghostdoor-start-highscore">
            <div class="ghostdoor-start-highscore-title">
                <h1>Highscore</h1>
            </div>
            <div class="ghostdoor-start-highscore-table">
                <table>
                    <tr>
                        <th>User</th>
                        <th>Score</th>
                    </tr>
                    <?php $__currentLoopData = $allscores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th><?php echo e($game->player); ?></th>
                            <th><?php echo e($game->score); ?></th>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </div>
        </div>
        <div class="footer">
            <p>Gemaakt door: <a href="https://vunzigeberen.vysix.nl">Vunzige Beren</a></p>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("Layouts.index", \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>