<?php $__env->startSection("browsertitle"); ?>
    In the castle
<?php $__env->stopSection(); ?>
<div class="ghostdoor-game">
    <?php if($gameOver == false): ?>
        <div class="ghostdoor-game-main">
            <?php if($score == 0): ?>
                <h1>You are in the first room I think there are 2 ghost's hidden behind one of the 5 doors</h1>
            <?php elseif($newRoom): ?>
                <h1><?php echo e($newRoom); ?></h1>
            <?php else: ?>
            <?php endif; ?>
            <?php if($score == 5): ?>
                <img src="/img/Kingboo.png" width="150">
                <h1>Oh no! I can hear more ghost's I think there are 3 ghost's hidden behind the 5 doors</h1>
            <?php endif; ?>
            <?php if($score == 10): ?>
                <img src="/img/Kingboo.png" width="150">
                <h1>Oh no! I can hear more ghost's I think there are 3 ghost's hidden behind the 4 doors</h1>
            <?php endif; ?>
            <?php if($score == 15): ?>
                <img src="/img/Kingboo.png" width="150">
                <h1>Oh no! I can hear more ghost's I think there are 2 ghost's hidden behind the 3 doors</h1>
            <?php endif; ?>
            <?php if($score == 20): ?>
                <img src="/img/Kingboo.png" width="150">
                <h1>Oh no! I can hear more ghost's I think there are 2 ghost's hidden behind the 3 doors</h1>
            <?php endif; ?>
            <?php if($score == 25): ?>
                <img src="/img/Kingboo.png" width="150">
                <h1>Oh no! I can hear more ghost's I think there are 2 ghost's hidden behind the 4 doors</h1>
            <?php endif; ?>
            <?php if($score == 30): ?>
                <img src="/img/Kingboo.png" width="150">
                <h1>Oh no! I can hear more ghost's I think there are 3 ghost's hidden behind the 5 doors</h1>
            <?php endif; ?>
            <h1>Level: <?php echo e($score); ?></h1>
            <pre>

            </pre>
            <form method="post" action="/play">
                <?php echo csrf_field(); ?>
                <div class="ghostdoor-game-doors">
                    <button type="submit" name="getal" value="1"><img src="/img/door1.png" alt="Door1"></button>
                    <button type="submit" name="getal" value="2"><img src="/img/door2.png" alt="Door1"></button>
                    <?php if($score > 15): ?>
                    <?php else: ?>
                        <button type="submit" name="getal" value="3"><img src="/img/door3.png" alt="Door1"></button>
                    <?php endif; ?>
                    <?php if($score >20): ?>
                        <button type="submit" name="getal" value="3"><img src="/img/door3.png" alt="Door1"></button>
                    <?php endif; ?>
                    <?php if($score > 10): ?>
                    <?php else: ?>
                        <button type="submit" name="getal" value="4"><img src="/img/door4.png" alt="Door1"></button>
                    <?php endif; ?>
                    <?php if($score > 25): ?>
                        <button type="submit" name="getal" value="4"><img src="/img/door4.png" alt="Door1"></button>
                    <?php endif; ?>
                    <?php if($score > 5): ?>
                    <?php else: ?>
                        <button type="submit" name="getal" value="5"><img src="/img/door5.png" alt="Door1"></button>
                    <?php endif; ?>
                    <?php if($score > 30): ?>
                        <button type="submit" name="getal" value="5"><img src="/img/door5.png" alt="Door1"></button>
                    <?php endif; ?>
                </div>
                <div class="ghostdoor-game-reset">
                    <input type="submit" value="reset" name="reset">
                </div>
            </form>
        </div>
    <?php else: ?>
        <div>
            <h1>Game over!</h1>
            <form method="post" action="/">
                <?php echo csrf_field(); ?>
                <input type="text" placeholder="Username" name="name">
                <input type="submit" value="Send">
            </form>
        </div>
    <?php endif; ?>
</div>
<?php echo $__env->make("Layouts.index", \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>