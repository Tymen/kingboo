@extends("Layouts.index")
@section("browsertitle")
    Game over!
@endsection
@section("content")
@endsection